import React from 'react';

const InventoryManagement = () => {
  return (
    <div>
      <h2>Inventory Management</h2>
      <p>Manage your inventory here.</p>
    </div>
  );
};

export default InventoryManagement;
