import React from 'react';

const VendorManagement = () => {
  return (
    <div>
      <h2>Vendor Management</h2>
      <p>Manage your vendors here.</p>
    </div>
  );
};

export default VendorManagement;
