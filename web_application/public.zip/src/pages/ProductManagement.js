import React from 'react';

const ProductManagement = () => {
  return (
    <div>
      <h2>Product Management</h2>
      <p>Manage your products here.</p>
    </div>
  );
};

export default ProductManagement;
