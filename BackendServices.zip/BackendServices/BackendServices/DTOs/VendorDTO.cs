﻿namespace BackendServices.DTOs;

public class VendorDTO
{
    public string VendorName { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }
    public string Category { get; set; }
}