﻿namespace BackendServices.Configurations;

// Configurations/MongoDBSettings.cs
public class MongoDBSettings
{
    public string ConnectionString { get; set; }
    public string DatabaseName { get; set; }
}
